#########
库API文档
#########

arduino-sg200x 提供了一些封装的模块, 以下是模块API说明:

.. toctree::
    :maxdepth: 1
    :glob:

    libraries/*

#########
示例文档
#########

arduino-sg200x 提供了一些示例代码, 以下是使用Arduino Core for Sg200x使用的代码:

#. pin定义。

    .. figure:: ./_static/pin.png
        :align: center
        :figclass: align-center

.. toctree::
    :maxdepth: 1
    :glob:

    examples/*
